rm a.out
gcc -fopenmp flush.c -O3

