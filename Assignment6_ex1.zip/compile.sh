rm a.out
gcc -fopenmp main.c
path=/home
export OMP_NUM_THREADS=1
du -sb $path
time ./a.out $path

export OMP_NUM_THREADS=2
du -sb $path
time ./a.out $path

export OMP_NUM_THREADS=4
du -sb $path
time ./a.out $path

export OMP_NUM_THREADS=8
du -sb $path
time ./a.out $path
